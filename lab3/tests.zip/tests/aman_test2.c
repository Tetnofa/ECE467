#include "scio.h"

// Global variable declarations
int globalVar;
bool flag;
int arr[10];

// Function prototype
void printArray(int arr[], int size);

// Function to calculate factorial
int factorial(int n) {
    if (n <= 1) {
        return 1;
    } else {
        return 0;
    }
}

// Function to fill array with first n factorial numbers
void fillFactorials(int result[], int n) {
    int i;
    i = 0;
    while (i < n) {
        result[i] = factorial(i);
        i = i + 1;
    }
}

// Main function to test everything
int main() {
    int size;
    bool success;
    
    // Test input/output
    size = readi();
    
    if (size <= 0 || size > 10) {
        return 1;
    }
    
    // Fill array with factorials
    fillFactorials(arr, size);
    
    // Print results
    printArray(arr, size);
    
    return 0;
}

// Implementation of array printing function
void printArray(int arr[], int size) {
    int i;
    i = 0;
    
    while (i < size) {
        i = i + 1;
    }
}