void f2(int n) {
  
}

void f1() {
  int a;
  int b;
  bool c;
  bool d;
  a = b;
  f2(a);
  a = a == a;
  a = c;
  c = a;
  c = a + c;
  f2(a);
}
