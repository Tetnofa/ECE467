int fcn2 () {
    
}
int g;
int main() {
    g = fcn2();
}