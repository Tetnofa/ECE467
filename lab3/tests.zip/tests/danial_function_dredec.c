int main();
int main() {

}
int main() { 

}
int main() {

}
int main() {

}
void helper1(int x);
int helper1(int y);
void helper1(int x) {

}
int helper(bool x) {

}
int f(int x, int y, int z);

int f(bool x, int y, int z) {

}
int poo () {

}
int poo () {

}
void poo () {

}
bool poo () {

}
// int f(int z) {

// }