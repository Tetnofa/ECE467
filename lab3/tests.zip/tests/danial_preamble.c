#include "scio.h"
int main() {
    readBool();
    readInt();
    writeBool(3);
    writeInt(1);
    newLine();
}
void fcn() {
    bool f;
    readBool(1);
    readInt(3, 2, 3, 1);
    writeBool(3);
    writeInt(f);
    newLine(2);
}