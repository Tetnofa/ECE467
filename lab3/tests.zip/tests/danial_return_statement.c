int main() {
    return true;
}
int f() {
    return;
}
void g() {
    return;
}
void gf() {
    return 2;
}
bool aldkaw(int x) {
    return x;
}
int a (int x, int y, int z) {
    {
        {
            {
                {
                    return z;
                }
            }
        }
    }
}
int gfcnad(int arr[]) {
    return arr[2];
}
void adlkdjwad(int b) {
    int f;
    return f;
}
bool adlkjawd(int f) {
    return f;
}
bool dawjdhaw(bool g[]) {
    return g[2];
}
int daawdawd(bool g[]) {
    return g[2];
}
void adwaawdjawdd(int x) {
    return x;
}