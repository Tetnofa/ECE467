//int z;
int main() { 
    // int x;
    // int z;
    int f;
    //g;
    //int y;
    {
        int z;
        {
            {
                {
                    f;
                    z;
                }
            }
        }
    }
}
void fcn () {
    int y;
    int z;
    int z;
    g;
}
int f;
void poo () {
    f;
}
int z;
int y;
int f;
bool fa () {
    int y;
    int z;
    int g;
    {
        int a;
        {
            a;
        }
    }
}