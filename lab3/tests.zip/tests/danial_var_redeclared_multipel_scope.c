// int x;
// int y;
// int a;
// int a;
//int arr[2];
//bool x;
int z;
int z;
int main() { 
    // int adawldhk; // shouldn't be called probably. NOT THE GLOBAL SCOPE
    // if (1) {
    //     int y;
    // }
    int x;
    int x;
    {
        int x;
        int y;
        int x;
        {
            int x;
            int x;
            int x;
        }
    }
    {
        int a;
        int b;
        {
            int a;
            int b;
            int c;
            {
                int a; 
                int c; 
                int d;
            }
        }
    }

    //int y;
}
void fcn () {
    int y;
    int z;
    int z;
}
int z;
int y;
int f;
bool fa () {
    int y;
    int z;
    int g;
}