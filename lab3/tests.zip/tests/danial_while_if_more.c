void pee() {
    int x;
    while (1) {
        int y;
        y = 9;
        if (x <= y && x >= y && y != 1 || 8 < 9 && !y) {
            if (x >= 9) {
                if (x != y) {

                }
            }
        }
    }
}