int main() {
    int x;
    x = 1;
    if (x == 1) {
        if (x == 1) {
            int y;
            y = 1;
            if (y != 1) {

            } else {
                if (y <= 2) {
                    if (z) {
                        if (z) {

                        }
                    }
                }
            }
        }
    }
}
void poo () {
    if (1 < x) {

    }
}
int a (int b, int c) {
    if (b < c) {
        if (x) {

        }else {
            if (b != c) {

            }
        }
    }
}
int f (int arr[],int b, int c) {
    if (arr[3] <= b) {
        f(arr, b, c);
    } else if (arr[3] >= c) {
        f(arr, b, c);
    } else if (arr[5] > y) {
        poo();
    }
}
void fcn() {
    while (1 < 2) {

    }
    while (x) {

    }
    while (y) {
        while ( 1 < 2) {
            while (x) {
                if (f) {
                    if (1 == 2) {
                        while (1 != 8) {
                            if (5==3) {
                                if (5 <= 3) {
                                    while (3) {

                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

void whileScope() {
    while (1) {
        int x;
        x = 2;
        if (x == 2) {
            int y;
        }
    }
}
void pee() {
    int x;
    while (1) {
        int y;
        y = 9;
        if (x <= y) {
            if (x >= 9) {
                if (x != y) {

                }
            }
        }
    }
}
bool fadwa() {
    bool x;
    bool y;
    while (x) {
        if (y) {

        }
    }
}