
void f1() {
  int a;
  a = a == a;
}
