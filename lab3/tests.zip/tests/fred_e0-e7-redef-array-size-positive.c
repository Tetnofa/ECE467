int a1[4];
int a1[-3];

int a2[-3];
int a2[1];
