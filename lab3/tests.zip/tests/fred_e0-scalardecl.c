int x;
int x;

void foo() {
  int y;
  int y;

  while (true) {
    int z;
    int z;
  }
}
