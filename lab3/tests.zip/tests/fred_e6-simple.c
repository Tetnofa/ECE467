int main() {
  true && false;
}
