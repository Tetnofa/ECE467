int arr1[0];
int arr2[1];
int arr3[-1];
