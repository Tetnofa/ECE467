void f1(int arr[]);

void f1(int arr[]) {
  
}
