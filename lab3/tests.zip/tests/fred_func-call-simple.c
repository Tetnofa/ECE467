
int f1(int a1[], int a2) { return 0; }

int f2() {
  int foo[6];
  f1(foo, 3);
}

