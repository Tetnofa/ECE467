void func() {
  return;
}
void func();

