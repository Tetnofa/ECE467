int f1() {
  bool b;
  if 
  (
  b
  ) {
    
  }
}
