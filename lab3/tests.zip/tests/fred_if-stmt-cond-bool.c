int f1() {
  int a;
  bool b;
  if (1) {
  }
  if (true) {
  }
  if (true) {

  } else {
  }
  if (a + a) {

  } else {
  }
  if (a == a && b) {

  } else {
  }
}
