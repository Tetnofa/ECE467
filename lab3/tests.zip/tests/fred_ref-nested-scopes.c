int a;

void f1() {
  bool a;
  int b;
  b = a;
}
