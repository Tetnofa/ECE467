int f1() {
  int a;
  bool b;
  while (1) {
  }
  while (true) {
  }
  while (true) {
  }
  while (a + a) {
  }
  while (a == a && b) {
  }
}
