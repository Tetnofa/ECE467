//
//  scio.h
//  
//
//  Created by Tarek Abdelrahman on 2023-04-25.
//

#ifndef scio_h
#define scio_h

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h> 

bool readBool();
int  readInt();
void writeBool(bool b);
void writeInt(int i);
void newLine();

#endif /* scio_h */

